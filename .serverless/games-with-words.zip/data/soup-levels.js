const levels = [
    {
        id: 0,
        letters: ["F", "U", "A", "S", "D", "E"],
        answers: ["FUSED", "FEUDS", "USED", "DEAF", "SAD", "SEA"],
    },
    {
        id: 1,
        letters: [],
        answers: [],
    },
    {
        id: 2,
        letters: [],
        answers: [],
    },
];

module.exports = levels;
