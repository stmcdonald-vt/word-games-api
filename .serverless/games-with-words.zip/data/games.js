const games = {
    alphabetSoup: {
        name: "Alphabet Soup",
        active: true,
    },
};
